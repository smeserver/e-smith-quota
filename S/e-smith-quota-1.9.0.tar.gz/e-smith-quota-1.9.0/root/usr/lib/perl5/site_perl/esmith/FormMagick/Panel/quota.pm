#!/usr/bin/perl -w
#
# Copyright (C) 2002 Mitel Networks Corporation
#
# Technical support for this program is available from e-smith, inc.
# Please call us at (613) 236-0743 or visit our web site www.e-smith.net
# for details.
#
# $Id: quota.pm,v 1.12 2003/04/04 20:44:38 lijied Exp $
#
#----------------------------------------------------------------------


package esmith::FormMagick::Panel::quota;

use strict;
use Exporter;
use Quota;
use esmith::AccountsDB;
use esmith::FormMagick;
use esmith::cgi;
use esmith::TestUtils;

our @ISA = qw(esmith::FormMagick Exporter);
our @EXPORT = qw(
	showInitial modifyUser performModifyUser
);
our $VERSION = sprintf '%d.%03d', q$Revision: 1.12 $ =~ /: (\d+).(\d+)/;

=pod

=head1 NAME

esmith::FormMagick::Panel::quota - useful panel functions

=head1 SYNOPSIS

	use esmith::FormMagick::Panel::quota;
	my $panel = esmith::FormMagick::Panel::quota->new();
	$panel->display();

=head1 DESCRIPTION

=head2 new

Exactly as for esmith::FormMagick

=begin testing

use_ok('esmith::FormMagick::Panel::quota');
$FM = esmith::FormMagick::Panel::quota->new();
isa_ok($FM, 'esmith::FormMagick::Panel::quota');
$FM->{cgi} = CGI->new;

=end testing

=cut

sub new
{
	shift;
	my $self = esmith::FormMagick->new();
	$self->{calling_package} = (caller)[0];
	bless $self;
	return $self;
}

=pod

=head2 showInitial

Display the contents of the initial page

=for testing
is($FM->showInitial(), '', 'showInitial');

=cut

sub showInitial
{
    my $self = shift;
    my $q = $self->{cgi};

    #------------------------------------------------------------
    # Look up accounts and user names
    #------------------------------------------------------------

    print '<tr><td>';
    my $adb = esmith::AccountsDB->open() 
	|| die $self->localise("UNABLE_TO_OPEN_ACCOUNTS");

    my @userAccounts = sort $adb->users;

    unless (scalar @userAccounts)
    {
	print $q->h3 ($self->localise('NO_ACCOUNTS'));
    }
    else
    {
	print $q->p ($self->localise('QUOTA_DESC')),"\n";
	print $q->h3 ($self->localise('CURRENT_USAGE_AND_SETTINGS')),"\n";
	#print $q->p ($q->b ($self->localise('CURRENT_USAGE_AND_SETTINGS')));
        print $q->Tr ($q->start_table({class => "sme-border"})),"\n";
        my $limit = $self->localise('LIMIT_WITH_GRACE_MB'); $limit =~ s#(grace)#<br>$1#;
	my $absolute = $self->localise('ABS_LIMIT_MB');     $absolute =~ s#(limit)#<br>$1#;
        my $current = $self->localise('CURRENT_USAGE');     $current =~ s#(usage)#<br>$1#;
        print $q->Tr (esmith::cgi::genSmallCell ($q, ($self->localise('ACCOUNT')),"header"),
		      esmith::cgi::genSmallCell ($q, ($self->localise('USER_NAME')),"header"),
		      esmith::cgi::genSmallCell ($q, $limit,"header"),
		      esmith::cgi::genSmallCell ($q, $absolute,"header"),
		      esmith::cgi::genSmallCell ($q, $current,"header"),
		      esmith::cgi::genSmallCell ($q, ($self->localise('ACTION')),"header"));

	foreach my $user (@userAccounts)
	{
	    my $uid = getpwnam($user->key);
	    unless ($uid)
	    {
		warn($self->localise('COULD_NOT_GET_UID'),$user->key);
		next;
	    }
	    my $dev = Quota::getqcarg('/home/e-smith/files');
	    my ($bc, $bs, $bh, $bt, $ic, $is, $ih, $it) =
		Quota::query($dev, $uid);

	    my $name = $user->prop("FirstName")." ".$user->prop("LastName");

	    print $q->Tr (esmith::cgi::genSmallCell ($q, $user->key,"normal"),
			  esmith::cgi::genSmallCell ($q, $name,"normal"),
			  esmith::cgi::genSmallCellRightJustified ($q, 
				$self->toMB($bs)),
			  esmith::cgi::genSmallCellRightJustified ($q, 
				$self->toMB($bh)),
			  esmith::cgi::genSmallCellRightJustified ($q, $self->toMB($bc)),
			  esmith::cgi::genSmallCell ($q, 
			    $q->a ({href => $q->url (-absolute => 1)
					. "?page=0&Next=Next&acct="
					. $user->key}, 
                                          $self->localise("MODIFY")),"normal"));
	}
	print '</table></table>';
    }
    print '</td></tr>';
	return '';
}

=pod

=head2 modifyUser

Display the modify user form for the specified user

=begin testing

$FM->{cgi}->param(-name=>'acct', -value=>'foononex');
is($FM->modifyUser(),'','modifyUser');
like($FM->{cgi}->param('status_message'), qr/NO_SUCH_ACCT/, 
	' .. no such account');

=end testing

=cut

sub modifyUser
{
    my $self = shift;
    my $q = $self->{cgi};

    my $adb = esmith::AccountsDB->open();
    my $acct = $q->param ('acct');
    my $rec = $adb->get($acct);
    unless (defined $rec)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('ERR_NO_SUCH_ACCT').$acct);
	return '';
    }
    my $type = $rec->prop('type');
    unless ($type eq "user")
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('ERR_NOT_A_USER_ACCT').$acct.
	    $self->localise('ACCOUNT_IS_TYPE').$type);
	return '';
    }
    my $uid = getpwnam($acct);
    unless ($uid)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('COULD_NOT_GET_UID').$acct);
	return '';
    }

    my $name = $rec->prop("FirstName")." ".$rec->prop("LastName");
    my $dev = Quota::getqcarg('/home/e-smith/files');
    my ($bc, $bs, $bh, $bt, $ic, $is, $ih, $it) =
		Quota::query($dev, $uid);

    print
	$q->p($self->localise('USER')."$name (\"$acct\") ".
	$self->localise('CURRENTLY_HAS')."$ic files ".
	$self->localise('OCCUPYING').$self->toMB($bc)." ".
	$self->localise('MEGABYTES'));

    print
	$q->p($self->localise('INSTRUCTIONS'));

    print $q->table ({border => 0, cellspacing => 0, cellpadding => 4},

	$q->Tr (esmith::cgi::genCell ($q, $self->localise("USER_NAME")),
		    esmith::cgi::genCell ($q, $name)),
	$q->Tr (esmith::cgi::genCell ($q, $self->localise('LIMIT_WITH_GRACE')),
	      esmith::cgi::genCell ($q,
			$q->textfield (-name     => 'soft',
				       -override => 1,
				       -default  => $self->toBestUnit($bs),
				       -size     => 12))),
	$q->Tr (esmith::cgi::genCell ($q, $self->localise('ABS_LIMIT')),
	      esmith::cgi::genCell ($q,
			$q->textfield (-name     => 'hard',
				       -override => 1,
				       -default  => $self->toBestUnit($bh),
				       -size     => 12))));
    return '';
}


=pod

=head2 performModifyUser

Perform the modifications requested by the Modify page

=begin testing

$FM->{cgi}->param(-name=>'acct', -value=>'fooquuxb');
is($FM->performModifyUser(),'','performModifyUser');
like($FM->{cgi}->param('status_message'), qr/NO_SUCH_ACCT/, 
	' .. no such account');

=end testing

=cut

sub performModifyUser
{
    my $self = shift;
    my $q = $self->{cgi};

    my $adb = esmith::AccountsDB->open();
    my $acct = $q->param ('acct');

    my $rec = $adb->get($acct);
    unless (defined $rec)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('ERR_NO_SUCH_ACCT').$acct);
	return '';
    }
    my $type = $rec->prop('type');
    unless ($type eq "user")
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('ERR_NOT_A_USER_ACCT').$acct.
	    $self->localise('ACCOUNT_IS_TYPE').$type);
	return '';
    }
    my $uid = getpwnam($acct);
    unless ($uid)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('COULD_NOT_GET_UID').$acct);
	return '';
    }
    my $softlim = $q->param ('soft');
    unless ($softlim =~ /^(\d+)\s*[kmg]?$/i)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('SOFT_VAL_MUST_BE_INTEGER'));
        return '';
    }
    my $value = $1;
    if($softlim =~ /g$/i)
    {
	$softlim = $self->GBtoKB($value);
    }
    elsif($softlim =~ /k$/i)
    {
	$softlim = $value;
    }
    else
    {
	$softlim = $self->MBtoKB($value);
    }

    my $hardlim = $q->param ('hard');
    unless ($hardlim =~ /^(\d+)\s*[kmg]?$/i)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('HARD_VAL_MUST_BE_INTEGER'));
        return '';
    }
    $value = $1;
    if($hardlim =~ /g$/i)
    {
	$hardlim = $self->GBtoKB($value);
    }
    elsif($hardlim =~ /k$/i)
    {
	$hardlim = $value;
    }
    else
    {
	$hardlim = $self->MBtoKB($value);
    }

    #------------------------------------------------------------
    # Make sure that soft limit is less than hard limit.
    #------------------------------------------------------------

    unless ($hardlim == 0 or $hardlim >= $softlim)
    {
	$self->wherenext('Initial');
	$q->param(-name=>'status_message', -value=>
	    $self->localise('ERR_HARD_LT_SOFT'));
	return '';
    }
	

    #------------------------------------------------------------
    # Update accounts database and signal the user-modify event.
    #------------------------------------------------------------

    $rec->set_prop('MaxBlocks', $hardlim);
    $rec->set_prop('MaxBlocksSoftLim', $softlim);

    system ("/sbin/e-smith/signal-event", "user-modify", "$acct") == 0
        or die ($self->localise('ERR_MODIFYING')."\n");

    $self->wherenext('Initial');
    $q->param(-name=>'status_message', -value=>
	$self->localise('SUCCESSFULLY_MODIFIED').$acct);
    return '';
}

=pod

=head2 toMB ($kb)

Utility function to convert KB to MB

=for testing
is($FM->toMB(1024),'1.00','toMB');

=cut

sub toMB
{
    my ($self,$kb) = @_;
    return sprintf("%.2f", $kb / 1024);
}

=pod

=head2 toMBNoDecimalPlaces ($kb)

Utility function to convert KB to MB with no decimal places

=for testing
is($FM->toMBNoDecimalPlaces(2050), '2', 'toMBNoDecimalPlaces');

=cut

sub toMBNoDecimalPlaces
{
    my ($self,$kb) = @_;
    return sprintf("%.0f", $kb / 1024);
}

sub toGBNoDecimalPlaces
{
    my ($self,$kb) = @_;
    return sprintf("%.0f", $kb / 1024 / 1024);
}


=pod

=head2 toKB ($mb)

Utility function to convert MB to KB.

=for testing
is($FM->toKB(4),'4096','toKB');

=cut

sub toKB 
{
    my ($self,$mb) = @_;
    return sprintf("%.0f", $mb * 1024);
}

=pod

Utility to convert GB to KB

=for testing
is($FM->GBtoKB(1),1048576,'GBtoKB');

=cut

sub GBtoKB
{
    my ($self,$gb) = @_;
    return sprintf("%.0f", $gb * 1024 * 1024);
}

sub MBtoKB
{
    my ($self,$mb) = @_;
    return sprintf("%.0f", $mb * 1024);
}

sub toBestUnit
{
    my ($self,$kb) = @_;
    return 0 if($kb == 0);
    return $kb."K" if($kb < 1024);
    return $kb."K" if($kb > 1024 && $kb < 1048576 && $kb % 1024 != 0);
    return $self->toMBNoDecimalPlaces($kb)."M" if($kb < 1048576);
    return $self->toMBNoDecimalPlaces($kb)."M" if($kb > 1048576 
	&& ($kb % 1048576 != 0));
    return $self->toGBNoDecimalPlaces($kb)."G";
}

1;

